<title>Sign Up</title>
<?php include 'views/header.php'; ?>

<form id="signinform" action="models/signup-user.php" method="POST">
    <label for="uname">Username</label>
    <?php
        if (isset($_GET['uname_error'])) {
            if ($_GET['uname_error'] == 1) {
                echo "<span class='error'>* Invalid username or username already exists</span>";
            }
        }
    ?>
    <input type="text" id="username" name="uname" placeholder="Username" required>

    <label for="email">Email</label>
    <?php
        if (isset($_GET['email_error'])) {
            if ($_GET['email_error'] == 1) {
                echo "<span class='error'>* Invalid email or email already exists</span>";
            }
        }
    ?>
    <input type="text" id="email" name="email" placeholder="Email" required>

    <label for="fname">Firstname</label>
    <input type="text" id="firstname" name="fname" placeholder="First name" required>

    <label for="lname">Lastname</label>
    <input type="text" id="lastname" name="lname" placeholder="Last name" required>

    <label for="gender">Gender</label>
    <select id="gender" name="gender" required>
        <option value="male">Male</option>
        <option value="female">Female</option>
    </select>

    <label for="bdate">Birthday</label>
    <input type="date" id="bdate" name="bdate" required>

    <label for="pass">Password</label>
    <?php
        if (isset($_GET['password_error'])) {
            if ($_GET['password_error'] == 1) {
                echo "<div class='error'>*Password doesn't match</div>";
            }
        }
    ?>
    <input type="password" id="pass" name="pass" placeholder="Password" required>

    <label for="cpass">Confirm Password</label>
    <input type="password" id="cpass" name="cpass" placeholder="Confirm Password" required>

    <div class="eula-container">
        <input type="checkbox" id="eula" name="eula" required>
        <label for="eula">I have read and agree to the <a href="eula.php">EULA</a></label>
    </div>

    <input type="submit" value="Sign Up">
</form>

<?php include 'views/footer.php'; ?>
