<title>Sign In</title>
<?php
session_start();

// Check if the user is already logged in
if (isset($_SESSION['uid'])) {
    header("Location: ./index.php");
    exit;
}

include 'views/header.php';
?>
<link href="res/mystyle.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>

<form id="signinform" action="models/signin-user.php" method="POST">
    <label for="uname">Username</label>
    <input type="text" id="username" name="uname" placeholder="Username" required>

    <label for="pass">Password</label>
    <input type="password" id="password" name="pass" placeholder="Password" required>

    <div id="signedinbox">
        <input type="checkbox" id="signedin" name="signin" value="signedin">
        <label for="signedin">Keep Me Signed In</label>
    </div>

    <input type="submit" value="Sign In">
</form>

<?php 
include 'views/footer.php';
?>
