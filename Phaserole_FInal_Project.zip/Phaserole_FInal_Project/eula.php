<?php include 'views/header.php'; ?>

<!-- Stylesheets -->
<link rel="stylesheet" href="res/eula.css?v=<?php echo time(); ?>">
<link href="https://fonts.googleapis.com/css2?family=Roboto+Mono&display=swap" rel="stylesheet">

<!-- EULA Container -->
<div class="eula-container">
    <h2>End User License Agreement (EULA)</h2>

    <p>
        Welcome to <strong>Phaserole</strong>! Before continuing, please take a moment to review our End User License Agreement (EULA). This agreement outlines your rights and responsibilities when using our platform.
    </p>

    <p>By accessing or using <strong>Phaserole</strong>, you acknowledge and agree to the following terms:</p>

    <ul>
        <li>You must be at least 16 years of age to use this platform.</li>
        <li>You are responsible for the content you post and must not upload illegal or offensive material.</li>
        <li>Your account may be suspended or terminated for violating these terms or our community guidelines.</li>
        <li>You must not use the platform for any unlawful, harmful, or disruptive activities.</li>
        <li>We reserve the right to update or modify this agreement at any time with reasonable notice.</li>
    </ul>

    <p>
        Continued use of <strong>Phaserole</strong> implies that you understand and agree to these terms. If you do not agree, please refrain from using the platform.
    </p>

    <a href="sign-up.php">Agree & Return to Sign Up</a>
</div>

<?php include 'views/footer.php'; ?>
