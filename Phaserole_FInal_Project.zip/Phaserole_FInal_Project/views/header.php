<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Reactor Page'; ?></title>
    
    <!-- Core Styles -->
    <link href="./res/mystyle.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>
    <link href="./res/search.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>
    <!-- Page-specific additional CSS -->
    <?php if (isset($additionalCSS)) echo $additionalCSS; ?>

    <!-- Font Awesome & JS -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script src="./scripts/live-search.js" defer></script>
</head>
<body>
    <div class="navbar">
        <!-- Left Section (Logo) -->
        <div class="navbar-left">
            <a href="./index.php" class="logo">
                <img src="./media/Phaserole_logo.png" alt="Logo">
            </a>
        </div>

        <!-- Center Section (Live Search Bar with Button) -->
        <div class="navbar-center">
            <form id="live-search-form" onsubmit="return false;">
                <input type="text" id="searchInput" name="query" placeholder="Search users or posts..." autocomplete="off">
                <div id="searchResults" class="live-results-box"></div>
            </form>
        </div>

        <!-- Right Section (About, Profile, Sign In/Out) -->
        <div class="navbar-right">
            <a href="./about.php">ABOUT</a>
            <?php if (isset($_SESSION['uid'])) { ?>  
                <a href="./profile.php">
                    <?php echo htmlspecialchars($_SESSION['fname'] . " " . $_SESSION['lname']); ?>
                </a>
                <a href="./models/sign-out.php">SIGNOUT</a>
            <?php } else { ?> 
                <a href="./sign-in.php">SIGN IN</a>
                <a href="./sign-up.php">SIGN UP</a>
            <?php } ?>
        </div>
    </div>
