<title>Home</title>
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'models/dbconnection.php';
include 'views/header.php';

$title = "Home";
?>
<link href="res/home.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>

<div class="home-container">
    <h1>HOME</h1>

    <!-- Search bar for posts -->
    <form action="index.php" method="GET" class="search-form">
        <input type="text" name="search_query" placeholder="Search posts..." value="<?php echo isset($_GET['search_query']) ? htmlspecialchars($_GET['search_query']) : ''; ?>" />
        <button type="submit">Search</button>
    </form>

    <!-- Container to load posts -->
    <div id="post-container">
        <?php
        $conn = create_connection();

        // Build the query based on search input
        $search_query = isset($_GET['search_query']) ? $_GET['search_query'] : '';
        if (!empty($search_query)) {
            $query = "SELECT p.*, u.username, u.uid AS user_id FROM post p JOIN user u ON p.uid = u.uid WHERE p.text_content LIKE ? ORDER BY p.date DESC, p.time DESC";
            $search_param = "%" . $search_query . "%";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $search_param);
        } else {
            $query = "SELECT p.*, u.username, u.uid AS user_id FROM post p JOIN user u ON p.uid = u.uid ORDER BY p.date DESC, p.time DESC";
            $stmt = $conn->prepare($query);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($post = $result->fetch_assoc()) {
                echo "<div class='post'>";
                echo "<p><strong><a href='profile.php?uid=" . htmlspecialchars($post['user_id']) . "' style='text-decoration: none; color: inherit;'>" . htmlspecialchars($post['username']) . "</a></strong></p>";
                echo "<p>" . nl2br(htmlspecialchars($post['text_content'])) . "</p>";
                echo "<p><em>Posted on: " . htmlspecialchars($post['date']) . " at " . htmlspecialchars($post['time']) . "</em></p>";

                // Comment form (only if logged in)
                if (isset($_SESSION['uid'])) {
                    echo "<div class='comment-form'>";
                    echo "<form action='models/add-comment.php' method='POST'>";
                    echo "<input type='hidden' name='pid' value='" . $post['pid'] . "'>";
                    echo "<textarea name='comment_text' placeholder='Write a comment...' required></textarea><br>";
                    echo "<button type='submit'>Comment</button>";
                    echo "</form>";
                    echo "</div>";
                } else {
                    echo "<p>You need to log in to comment.</p>";
                }

                // Display all comments (visible to everyone)
                $comment_stmt = $conn->prepare("SELECT c.*, u.username, u.uid AS comment_user_id FROM comment c JOIN user u ON c.uid = u.uid WHERE c.pid = ? ORDER BY c.date, c.time");
                $comment_stmt->bind_param("i", $post['pid']);
                $comment_stmt->execute();
                $comment_result = $comment_stmt->get_result();

                if ($comment_result->num_rows > 0) {
                    echo "<div class='comments'>";
                    while ($comment = $comment_result->fetch_assoc()) {
                        echo "<div class='comment'>";
                        echo "<p><strong>" . htmlspecialchars($comment['username']) . ":</strong> ";
                        echo nl2br(htmlspecialchars($comment['comment_text'])) . "<br>";
                        echo "<small><em>On " . htmlspecialchars($comment['date']) . " at " . htmlspecialchars($comment['time']) . "</em></small></p>";
                        echo "</div>";
                    }
                    echo "</div>";
                }

                $comment_stmt->close();
                echo "</div><hr>";
            }
        } else {
            echo "<p>No posts found.</p>";
        }

        $stmt->close();
        $conn->close();
        ?>
    </div>
</div>

<script src="scripts/load-posts.js"></script>

<?php include 'views/footer.php'; ?>
