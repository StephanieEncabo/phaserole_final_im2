<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require 'dbconnection.php';

$conn = create_connection();

if ($conn) {
    // Check if the user is logged in
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];

        // Fetch posts for the logged-in user
        $query = "SELECT p.*, u.username FROM post p JOIN user u ON p.uid = u.uid WHERE p.uid = ? ORDER BY p.date DESC, p.time DESC";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
    } else {
        // Fetch posts for all users if not logged in
        $query = "SELECT p.*, u.username FROM post p JOIN user u ON p.uid = u.uid ORDER BY p.date DESC, p.time DESC";
        $stmt = $conn->prepare($query);
    }

    // Execute and fetch results
    $stmt->execute();
    $result = $stmt->get_result();

    $posts = [];
    while ($post = $result->fetch_assoc()) {
        $posts[] = $post;
    }

    // Return posts as JSON
    echo json_encode($posts);

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["error" => "Database connection failed"]);
}
?>
