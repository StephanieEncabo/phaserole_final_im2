<?php
require_once('dbconnection.php');

$conn = create_connection();

$query = isset($_GET['query']) ? trim($_GET['query']) : '';

if (empty($query)) {
    echo json_encode([]);
    exit;
}

$searchTerm = "%" . $conn->real_escape_string($query) . "%";

// Search users
$userSQL = $conn->prepare("SELECT uid, firstname, lastname, username, profile_pic FROM user WHERE firstname LIKE ? OR lastname LIKE ? OR username LIKE ?");
$userSQL->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
$userSQL->execute();
$userResult = $userSQL->get_result();

$users = [];
while ($row = $userResult->fetch_assoc()) {
    $row['type'] = 'user';
    $users[] = $row;
}

// Search posts
$postSQL = $conn->prepare("SELECT p.pid, p.text_content, u.firstname, u.lastname FROM post p JOIN user u ON p.uid = u.uid WHERE p.text_content LIKE ?");
$postSQL->bind_param("s", $searchTerm);
$postSQL->execute();
$postResult = $postSQL->get_result();

$posts = [];
while ($row = $postResult->fetch_assoc()) {
    $row['type'] = 'post';
    $posts[] = $row;
}

// Merge and return both results
echo json_encode(array_merge($users, $posts));
?>
