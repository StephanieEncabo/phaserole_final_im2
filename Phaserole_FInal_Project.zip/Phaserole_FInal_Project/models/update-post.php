<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("Location: ../sign-in.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    require 'dbconnection.php';
    $conn = create_connection();

    $pid = $_POST['pid'];
    $text_content = $_POST['text_content'];

    $query = "UPDATE post SET text_content = ? WHERE pid = ? AND uid = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sii", $text_content, $pid, $_SESSION['uid']);

    if ($stmt->execute()) {
        header("Location: ../profile.php"); // Or wherever you want to go
    } else {
        echo "Error updating post.";
    }

    $stmt->close();
    $conn->close();
}
?>
