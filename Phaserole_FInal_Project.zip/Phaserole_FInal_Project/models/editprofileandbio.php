<?php
session_start();
require 'dbconnection.php';

$conn = create_connection();

if (!isset($_SESSION['uid'])) {
    die("You are not logged in.");
}

$uid = $_SESSION['uid'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $birthdate = $_POST['birthdate'];
    $password = $_POST['password']; // ⚠️ Consider hashing in future
    $bio = $_POST['bio'];

    $stmt = $conn->prepare("
        UPDATE user 
        SET username = ?, firstname = ?, lastname = ?, email = ?, gender = ?, birthdate = ?, password = ?, bio = ? 
        WHERE uid = ?
    ");
    $stmt->bind_param("ssssssssi", $username, $firstname, $lastname, $email, $gender, $birthdate, $password, $bio, $uid);

    if ($stmt->execute()) {
        // ✅ Update session so navbar reflects new name immediately
        $_SESSION['fname'] = $firstname;
        $_SESSION['lname'] = $lastname;

        header("Location: ../profile.php?update=success");
        exit();
    } else {
        echo "Update failed: " . $stmt->error;
    }

    $stmt->close();
}
?>
