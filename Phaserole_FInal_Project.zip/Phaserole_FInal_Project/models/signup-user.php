<?php
require 'dbconnection.php';

// Get and sanitize the form inputs
$un = htmlspecialchars($_POST['uname']);
$fn = htmlspecialchars($_POST['fname']);
$ln = htmlspecialchars($_POST['lname']);
$em = htmlspecialchars($_POST['email']);
$gen = htmlspecialchars($_POST['gender']);
$bdate = htmlspecialchars($_POST['bdate']);
$pass = htmlspecialchars($_POST['pass']);
$cpass = htmlspecialchars($_POST['cpass']);

// Check if the EULA checkbox is checked
$eula_accepted = isset($_POST['eula']) && $_POST['eula'] === 'on';

// If the EULA checkbox is not checked, redirect back with an error
if (!$eula_accepted) {
    header("Location: ../sign-up.php?eula_error=1");
    exit();
}

// Create a connection to the database
$con = create_connection();

if ($con->connect_error) {
    die("Connection Failed:" . $con->error);
}

// Check if the username already exists
$sql_uname = "SELECT * FROM user WHERE username='$un'";
$result_uname = $con->query($sql_uname);
$uname_error = 0;
if ($result_uname->num_rows > 0) {
    $uname_error = 1;
}

// Check if the email already exists
$sql_email = "SELECT * FROM user WHERE email='$em'";
$result_email = $con->query($sql_email);
$email_error = 0;
if ($result_email->num_rows > 0) {
    $email_error = 1;
}

// Check if the passwords match
$password_error = 0;
if (strcmp($pass, $cpass) != 0) {
    $password_error = 1;
}

// If no errors, insert the user into the database
if ($uname_error == 0 && $email_error == 0 && $password_error == 0) {
    // Store the password as plain text (again, not recommended for live apps)
    $sql = "INSERT INTO user (username, firstname, lastname, email, gender, birthdate, password) 
            VALUES ('$un', '$fn', '$ln', '$em', '$gen', '$bdate', '$pass')";
    $con->query($sql);

    // Redirect to the sign-in page with a success message
    header("Location: ../sign-in.php?reg_success=1");
} else {
    // Redirect back to sign-up page with error messages
    header("Location: ../sign-up.php?uname_error=$uname_error"
        . "&email_error=$email_error"
        . "&password_error=$password_error");
}
?>
