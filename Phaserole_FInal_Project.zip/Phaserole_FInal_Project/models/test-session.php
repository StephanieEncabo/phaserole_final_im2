<?php
session_start();
include '../config/dbconnection.php'; // ✅ Make sure the path is correct

if (isset($_SESSION['uid'])) {
    $conn = create_connection(); // ✅ Create connection

    $uid = $_SESSION['uid'];
    $result = $conn->query("SELECT * FROM user WHERE uid = $uid");

    if ($result) {
        if ($result->num_rows > 0) {
            echo "✅ User exists with uid = $uid";
        } else {
            echo "❌ No user found with uid = $uid";
        }
    } else {
        echo "❌ Error: " . $conn->error;
    }

    $conn->close();
} else {
    echo "❌ Session uid is not set.";
}
