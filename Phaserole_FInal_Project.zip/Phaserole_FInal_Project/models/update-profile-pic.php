<?php
session_start();
require 'dbconnection.php';

if (!isset($_SESSION['uid'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated.']);
    exit;
}

$con = create_connection();

if ($con->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$uid = $_SESSION['uid'];

if (!empty($_FILES['profile_picture']['name'])) {
    $targetDir = "../uploads/";
    $fileName = basename($_FILES['profile_picture']['name']);
    $targetFilePath = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

    // ✅ Allowed file types
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $targetFilePath)) {
            $profilePicture = "uploads/" . $fileName;

            // ✅ Update profile picture in the database
            $sql = "UPDATE user SET profile_pic = ? WHERE uid = ?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("si", $profilePicture, $uid);

            if ($stmt->execute()) {
                echo json_encode(['success' => true, 'newProfilePic' => $profilePicture]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update profile picture.']);
            }

            $stmt->close();
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to upload file.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid file type.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'No file uploaded.']);
}

$con->close();
exit;
