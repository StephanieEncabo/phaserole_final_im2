<?php
session_start();
require 'dbconnection.php';

$un = htmlspecialchars($_POST['uname']); // Username or email
$pass = htmlspecialchars($_POST['pass']); // Password

$con = create_connection();

if ($con->connect_error) {
    die("Connection Failed: " . $con->error);
}

// Prepared statement to prevent SQL injection
$sql = "SELECT * FROM user WHERE username = ? OR email = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("ss", $un, $un); // Check for either username or email
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // ✅ Check plain-text password (no hashing)
    if ($pass == $row['password']) { // Direct comparison for plain-text password
        $_SESSION['uid'] = $row['uid'];
        $_SESSION['fname'] = $row['firstname'];
        $_SESSION['lname'] = $row['lastname'];

        // ✅ Keep Me Signed In (Set cookies)
        if (isset($_POST['signin'])) {
            setcookie("uid", $row['uid'], time() + (86400 * 30), "/"); // 30 days
            setcookie("fname", $row['firstname'], time() + (86400 * 30), "/");
            setcookie("lname", $row['lastname'], time() + (86400 * 30), "/");
        }

        header("Location: ../index.php");
        exit;
    } else {
        header("Location: ../sign-in.php?signin_error=1"); // Wrong password
        exit;
    }
} else {
    header("Location: ../sign-in.php?signin_emailerror=1"); // Wrong username or email
}

$stmt->close();
$con->close();
?>
