<?php 
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['uid'])) {
    header("Location: ../sign-in.php");
    exit();
}

// Check if the post id is set and it's a GET request
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET['pid'])) {
    require 'dbconnection.php';
    $conn = create_connection();

    $pid = $_GET['pid'];

    // Prepare the SQL query to delete the post
    $query = "DELETE FROM post WHERE pid = ? AND uid = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $pid, $_SESSION['uid']);

    if ($stmt->execute()) {
        // Use the HTTP_REFERER or fallback to index.php
        $redirect_url = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '../index.php';

        // Redirect after successful execution
        header("Location: $redirect_url");
        exit();  // Ensure no further code is executed
    } else {
        // Log the error for debugging purposes
        error_log("Error deleting post: " . $stmt->error);
        echo "Error deleting post.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // If POST data is not valid or 'pid' is missing
    echo "Invalid request.";
}
?>
