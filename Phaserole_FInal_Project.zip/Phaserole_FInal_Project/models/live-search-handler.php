<?php
require_once('dbconnection.php');
$conn = create_connection();

header('Content-Type: application/json');

$query = isset($_GET['query']) ? trim($_GET['query']) : '';

if (empty($query)) {
    echo json_encode([]);
    exit;
}

$searchTerm = "%" . $conn->real_escape_string($query) . "%";

// USERS
$userSQL = $conn->prepare("SELECT uid, firstname, lastname, username, profile_pic FROM user WHERE firstname LIKE ? OR lastname LIKE ? OR username LIKE ?");
$userSQL->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
if (!$userSQL->execute()) {
    echo json_encode(['error' => 'User query failed: ' . $userSQL->error]);
    exit;
}
$userResult = $userSQL->get_result();
$users = [];
while ($row = $userResult->fetch_assoc()) {
    $users[] = [
        'type' => 'user',
        'uid' => $row['uid'],
        'name' => $row['firstname'] . ' ' . $row['lastname'],
        'username' => $row['username'],
        'profile_pic' => $row['profile_pic'] ? $row['profile_pic'] : './media/default-profile.png'
    ];
}

// POSTS
$postSQL = $conn->prepare("SELECT p.pid, p.text_content, u.firstname, u.lastname FROM post p JOIN user u ON p.uid = u.uid WHERE p.text_content LIKE ?");
$postSQL->bind_param("s", $searchTerm);
if (!$postSQL->execute()) {
    echo json_encode(['error' => 'Post query failed: ' . $postSQL->error]);
    exit;
}
$postResult = $postSQL->get_result();
$posts = [];
while ($row = $postResult->fetch_assoc()) {
    $posts[] = [
        'type' => 'post',
        'pid' => $row['pid'],
        'text_content' => $row['text_content'],
        'author' => $row['firstname'] . ' ' . $row['lastname']
    ];
}

echo json_encode(array_merge($users, $posts), JSON_UNESCAPED_UNICODE);
?>
