<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require 'dbconnection.php';
$conn = create_connection();

if (!$conn) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$userId = isset($_SESSION['uid']) ? $_SESSION['uid'] : null;

if (!$userId) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT * FROM post WHERE uid = ? ORDER BY date DESC, time DESC");
    $stmt->execute([$userId]);
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'posts' => $posts]);
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Database Error: ' . $e->getMessage()]);
}
exit;
?>
