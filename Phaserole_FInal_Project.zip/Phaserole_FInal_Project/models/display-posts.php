<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['uid'])) {
    $uid = $_SESSION['uid'];

    require_once 'dbconnection.php';
    $conn = create_connection();

    if ($conn) {
        $query = "SELECT p.*, u.username FROM post p JOIN user u ON p.uid = u.uid WHERE p.uid = ? ORDER BY p.date DESC, p.time DESC";
        $stmt = $conn->prepare($query);

        if (!$stmt) {
            echo "Error preparing query: " . $conn->error;
        } else {
            $stmt->bind_param("i", $uid); // Only show logged-in user's posts
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while ($post = $result->fetch_assoc()) {
                    echo "<div class='post'>";
                    echo "<p><strong>" . htmlspecialchars($post['username']) . "</strong></p>";
                    echo "<p>" . nl2br(htmlspecialchars($post['text_content'])) . "</p>";
                    echo "<p><em>Posted on: " . htmlspecialchars($post['date']) . " at " . htmlspecialchars($post['time']) . "</em></p>";

                    // Edit & Delete
                    echo "<form action='models/edit-post.php' method='POST' style='display:inline; margin-right: 10px;'>
                            <input type='hidden' name='pid' value='" . $post['pid'] . "'>
                            <button type='submit'>Edit</button>
                          </form>";
                    echo "<form action='models/delete-post.php' method='POST' style='display:inline;'>
                            <input type='hidden' name='pid' value='" . $post['pid'] . "'>
                            <button type='submit' onclick='return confirm(\"Delete this post?\")'>Delete</button>
                          </form>";

                    // 💬 Comment Form
                    echo "<div class='comment-form'>";
                    echo "<form action='models/add-comment.php' method='POST'>";
                    echo "<input type='hidden' name='pid' value='" . $post['pid'] . "'>";
                    echo "<textarea name='comment_text' placeholder='Write a comment...' required></textarea><br>";
                    echo "<button type='submit'>Comment</button>";
                    echo "</form>";
                    echo "</div>";

                    // 💬 Display Comments
                    $comment_stmt = $conn->prepare("SELECT c.*, u.username FROM comment c JOIN user u ON c.uid = u.uid WHERE c.pid = ? ORDER BY c.date, c.time");
                    $comment_stmt->bind_param("i", $post['pid']);
                    $comment_stmt->execute();
                    $comment_result = $comment_stmt->get_result();

                    if ($comment_result->num_rows > 0) {
                        echo "<div class='comments'>";
                        while ($comment = $comment_result->fetch_assoc()) {
                            echo "<p><strong>" . htmlspecialchars($comment['username']) . ":</strong> ";
                            echo nl2br(htmlspecialchars($comment['comment_text'])) . "<br>";
                            echo "<small><em>On " . $comment['date'] . " at " . $comment['time'] . "</em></small></p>";
                        }
                        echo "</div>";
                    }

                    $comment_stmt->close();

                    echo "</div><hr>";
                }
            } else {
                echo "<p>No posts found.</p>";
            }

            $stmt->close();
        }
    } else {
        echo "<p>Connection failed. Please try again later.</p>";
    }
} else {
    echo "<p>You need to be logged in to view posts.</p>";
}
?>
