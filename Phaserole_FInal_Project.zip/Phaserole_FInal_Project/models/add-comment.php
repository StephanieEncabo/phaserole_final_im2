<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['uid'])) {
    exit("Not logged in.");
}

require_once 'dbconnection.php';
$conn = create_connection();

$uid = $_SESSION['uid'];
$pid = $_POST['pid'];
$comment = trim($_POST['comment_text']);
$date = date("Y-m-d");
$time = date("H:i:s");

if ($comment !== '') {
    $stmt = $conn->prepare("INSERT INTO comment (pid, uid, comment_text, date, time) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $pid, $uid, $comment, $date, $time);
    $stmt->execute();
    $stmt->close();
}

// Set a message or status for the page
$_SESSION['comment_status'] = "success"; // or error

// Redirect back to the same page (either profile or homepage)
header("Location: " . $_SERVER['HTTP_REFERER']);
exit();
?>
