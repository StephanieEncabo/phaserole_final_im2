document.addEventListener('DOMContentLoaded', () => {
    const profileForm = document.getElementById('profilePicForm');

    // ✅ Define the function first
    function handleProfileUpload(event) {
        event.preventDefault();

        const formData = new FormData(profileForm);

        // ✅ Disable submit button to prevent double submission
        const submitButton = profileForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;

        fetch('models/update-profile-pic.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Profile picture updated successfully.');
                document.querySelector('img[alt="Profile Picture"]').src = `${data.newProfilePic}?t=${new Date().getTime()}`;

                // ✅ Refresh the page after a short delay (optional)
                setTimeout(() => {
                    location.reload();
                }, 500);
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to update profile picture.');
        })
        .finally(() => {
            // ✅ Re-enable submit button after request completes
            submitButton.disabled = false;
        });
    }

    // ✅ Remove any existing event listener and attach only one (avoid duplicates)
    profileForm.removeEventListener('submit', handleProfileUpload);
    profileForm.addEventListener('submit', handleProfileUpload, { once: true });
});
