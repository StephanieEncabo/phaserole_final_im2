$(document).ready(function () {
    loadPosts();  // Load posts when the page loads

    // Function to load posts dynamically for the profile
    function loadPosts() {
        $.ajax({
            type: 'GET',
            url: 'models/get-posts.php',  // PHP script to get posts for the logged-in user
            success: function (data) {
                console.log('🔄 Posts reloaded successfully');
                
                if (data.success) {
                    let postsHtml = '';
                    data.posts.forEach(post => {
                        postsHtml += `
                            <div class="post">
                                <p>${post.text_content}</p>
                                <p><small>${post.date} ${post.time}</small></p>
                            </div>
                        `;
                    });
                    $('#post-container').html(postsHtml);  // Update the post container with the new posts
                } else {
                    $('#post-container').html('<p>No posts found.</p>');
                }
            },
            error: function (xhr) {
                console.error('❌ Error loading posts:', xhr.responseText);
                $('#post-container').html('<p>Error loading posts.</p>');
            }
        });
    }
});
