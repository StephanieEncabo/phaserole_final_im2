document.addEventListener('DOMContentLoaded', () => { 
    const coverForm = document.getElementById('coverPhotoForm');

    // ✅ Define the function first
    function handleCoverUpload(event) {
        event.preventDefault(); // 🛠️ Prevent default form submission

        const formData = new FormData(coverForm);

        // ✅ Disable submit button to prevent double submission
        const submitButton = coverForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;

        fetch('models/update-cover-photo.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Cover photo updated successfully.');
                
                // ✅ Prevent caching by adding a timestamp
                const coverImg = document.getElementById('currentCoverPhoto');
                coverImg.src = `${data.newCoverPhoto}?t=${new Date().getTime()}`;

                // ✅ Refresh the page after a short delay (optional)
                setTimeout(() => {
                    location.reload();
                }, 500);
            } else {
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to update cover photo.');
        })
        .finally(() => {
            // ✅ Re-enable submit button after request completes
            submitButton.disabled = false;
        });
    }

    // ✅ Remove any existing event listener and attach only one (avoid duplicates)
    coverForm.removeEventListener('submit', handleCoverUpload);
    coverForm.addEventListener('submit', handleCoverUpload, { once: true });
});
