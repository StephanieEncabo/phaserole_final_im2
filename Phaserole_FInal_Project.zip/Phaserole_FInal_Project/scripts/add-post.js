$(document).ready(function () {
    // Handle post submission
    $('#add-post-form').on('submit', function (e) {
        e.preventDefault();  // Prevent the default form submission

        let formData = new FormData(this);

        $.ajax({
            type: 'POST',
            url: 'models/add-post.php',  // Specify the target PHP script for AJAX
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
                console.log('🟢 Raw Response:', response);

                try {
                    let result = JSON.parse(response);  // Parse the JSON response
                    console.log('✅ Parsed Response:', result);

                    if (result.success) {
                        $('#add-post-form')[0].reset();  // Reset the form on success
                        loadPosts();  // Reload posts dynamically

                        // Show success floating alert
                        showFloatingAlert(result.message, 'success');
                    } else {
                        // Show error floating alert if the post failed
                        showFloatingAlert(result.message, 'error');
                    }
                } catch (error) {
                    console.error('❌ JSON Parsing Error:', error, response);
                    showFloatingAlert('An error occurred while posting.', 'error');
                }
            },
            error: function (xhr) {
                console.error('❌ AJAX Error:', xhr.responseText);
                showFloatingAlert('Failed to add post. Please try again.', 'error');
            }
        });
    });

    // Function to load posts
    function loadPosts() {
        $.ajax({
            type: 'GET',
            url: 'models/get-posts.php',
            success: function (data) {
                if (data.success) {
                    let postsHtml = '';
                    data.posts.forEach(post => {
                        postsHtml += `
                            <div class="post">
                                <p>${post.text_content}</p>
                                <p><small>${post.date} ${post.time}</small></p>
                            </div>
                        `;
                    });
                    $('#post-container').html(postsHtml);
                }
            }
        });
    }

    // Floating alert function for success/error messages
    function showFloatingAlert(message, type) {
        let alert = $('<div class="floating-alert ' + type + '">' + message + '</div>');
        $('body').append(alert);  // Add the alert to the body
        alert.fadeIn().delay(3000).fadeOut(function() {
            $(this).remove();  // Remove the alert after it fades out
        });
    }
});
