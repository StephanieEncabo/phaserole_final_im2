<title>About</title>
<?php
$pageTitle = "About";

include 'views/header.php';
?>
<link href="res/about.css?v=<?php echo time(); ?>" rel="stylesheet" type="text/css"/>
<br>
<br>
<br>
<div class="content">
    <h1>About Phaserole</h1>
    <p>
        Phaserole is a next-generation social media platform built for creative expression, dynamic interaction, 
        and immersive digital presence. Whether you're sharing thoughts, managing your online identity, or exploring 
        content from others, Phaserole offers a sleek and intuitive space to do it all. With powerful customization tools, 
        real-time engagement features, and a vibrant community at its core, Phaserole isn't just another social network — 
        it's where your online role takes the spotlight.
    </p>
</div>

<div class="copyright">
    <p>Copyright 2025 @ Phaserole, All Rights Reserved.</p>
</div>

<?php include 'views/footer.php'; ?>
